import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';

function Update() {
  const { id } = useParams();
  const [values, setValues]= useState({
    id: id,
    goalName: "",
    goalStatus: ""
  })
  useEffect(()=>{
    axios.get( `http://3.84.182.197:3010/getGoals/`+id)
    .then(res => console.log(res))
    setValues({...values, goalName: res.data.goalName , goalStatus: res.data.goalStatus})
    .catch(err => console.log(err))
  }, [])

  const 
    axios.post(`http://3.84.182.197:3010/updateGoal`, updatedData)
      .then(() => {
        console.log('Update successful');
        navigate('/read');
      })
      .catch((error) => {
        console.error('Error updating data:', error);
      });
  }, []) 

  return (
    <div className="container">
      <h2>Update Goal</h2>
      <form onSubmit={handleUpdate}>
        <div className="mb-3">
          <label htmlFor="goalName">Goal Name</label>
          <input
            type="text"
            className="form-control"
            id="goalName"
            value={values.goalName}
            onChange={e => setValues({...values, goalName: e.target.value})}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="goalStatus">Goal Status</label>
          <input
            type="text"
            className="form-control"
            id="goalStatus"
            value={values.goalStatus}
            onChange={e => setValues({...values, goalName: e.target.value})}

          />
        </div>
        <button type="submit" className="btn btn-success">Update</button>
        <Link to="/read" className="btn btn-primary ms-3">Back</Link>
      </form>
    </div>
  );
}

export default Update;
